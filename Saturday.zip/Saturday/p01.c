#include <stdio.h>

int main()
{
	char seq[ 1000 ];
	scanf("%s", seq);

}

