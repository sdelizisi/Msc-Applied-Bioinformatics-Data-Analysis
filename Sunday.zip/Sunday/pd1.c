#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	char seq[ 1000 ];
	int len;

{
	scanf("%s", seq);
	len = strlen( seq );
	if ( len < 3 )
		{
			printf("Go away !\n");
			exit ( 1 ) ;
		}
	{
		if( seq[ 0 ] == 'A' && seq[ 1 ] == 'T' && seq[ 2 ] == 'G' )
			{
				printf("ATG presents !\n");
			}

		 else
			{
				printf("ATG_not_present. \n");
			}


	}


}

}

